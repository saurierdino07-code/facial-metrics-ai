# Facial Metrics AI

Browserbasierte Gesichtspunkt-Erkennung mit MediaPipe Face Landmarker. Die Messwerte sind geometrische Näherungen, keine validierte Attraktivitätsbewertung.

## GitHub Pages
1. Neues öffentliches Repository auf GitHub erstellen (z. B. `facial-metrics-ai`).
2. `index.html` im Stammverzeichnis hochladen und committen.
3. Settings → Pages → Build and deployment → Deploy from a branch → `main` / `(root)` → Save.
4. Nach dem Deployment erscheint die URL unter Settings → Pages, gewöhnlich `https://BENUTZERNAME.github.io/facial-metrics-ai/`.

Fotos werden lokal im Browser verarbeitet. MediaPipe-JavaScript und Modell werden beim Start von externen Servern geladen.
